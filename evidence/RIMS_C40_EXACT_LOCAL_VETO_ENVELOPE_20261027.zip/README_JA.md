# RIMS C40 — Source-locked local veto envelope and continuity audit

**2026-10-27 JST. Shuji Maruyama. © 2026 Shuji Maruyama. All rights reserved.**

## 完了した作業の範囲

C39 Run #2からダウンロードされた**実際の** `rims-c39-veto-source-terms.zip`（SHA256 `08318f04e7d1e7a0edfa7a69eefd1c2dcf0c19c152ef4640db7b6b33df83e160`）とC37原本を**無改変で**取り込み、保存済み `audit_c39_run2.py` によるソース系譜／C35 SHA履歴／original native vetoの再監査を実行した。更にC39が報告する独立物理量を使い、RIMSの実装済み結合質量曲率の厳密な二次式から「**固定した同一背景点における反実仮想的s区間**」を導出し、全数値を照合した。

**36件のローカル回帰テストPASS**（旧C39独立監査14件とC40回帰22件）。新たなCLASS実行、MCMC、パラメータフィット、solver救済は**0件**。**C40は物理的最終背景や宇宙論的モデル選好のproduction結果ではない。**

## 元のC39現物からのみ得られる数値

- `case=rims_002`, original 81 input SHA256 `0893eb71e09208c2579652d405f54277647f92ce1de33ee8a0e492ce2547cda0`。
- 実測拒否点：`a=3.9459045585355262e-10`、`s=0.64999999997593583`、`m_eff²/H²=-1.0049389722010728e-10`。
- 本来の拒否条件：`m_eff²/H² < -1e-10`。余剰 `4.9389722010727813e-13`。
- `A≡Vpp/H²=+3.7874156845567591e-129`、`B≡3rho_idm m_(phi phi)/m /H²=-1.0049389722010728e-10`。符号は結合項支配、相殺数K=1。
- 元C35先頭1,000文字 SHA一致 **FAILのまま**。診断ソース21行追加に伴う5箇所の行番号差のみ除去した別系統完全照合 **PASS**。既存の失敗履歴を書き換えていない。

## C40の新規・厳密な解析的整理（source equation, not new gravitational action）

```
g(s) := (1-s)(3s-1) = 1/3 - 3(s-2/3)^2
m_(phi phi)/m = -alpha_U^2 * g(s)

A := Vpp/H²
U := (rho_idm/H²) * alpha_U² >= 0
M(s; A,U) := A - U[1-9(s-2/3)^2]

original native veto iff M < -tau,  tau=1e-10.
```

At the actually observed state, `alpha_U=.01`, `U=1.0074576162489684e-10`, `A=3.787415684556759e-129`, hence `f=1-9(s-2/3)^2=0.9974999999927807`, or **99.75% of the maximal negative coupling curvature**. If `0 < (A+tau)/U < 1`, the strict veto occupies the **conditional fixed-A,U slice**:

```
2/3-sqrt((1-(A+tau)/U)/9) < s < 2/3+sqrt((1-(A+tau)/U)/9)
```

With the measured fixed A,U this is **`0.6379875765259604 < s < 0.6953457568073729`**. The original native s≈.65 lies inside. The exact local value M agrees with original CLASS to recorded double precision. The equality edges are *excluded* by the `class_test` strict inequality.

### 重要：絶対に一般化しない

This envelope is only true while **both `A=Vpp/H²` and `U=(rho/H²)*alpha_U²` are held fixed**. Real RIMS trajectory has `A(a)` and `U(a)` evolving with `s(a)`. Therefore it is **not** an interval of stable cosmic times, observational redshifts, fully normalized solutions, admissible RIMS parameter posterior, eigenmode instability interval, or universal `s`-selection theorem. For any claimed cosmological assertion, full CLASS trajectory and full coupled perturbation safety tests remain necessary. The analytic completed-square polynomial alone is elementary algebra, not a standalone novelty claim. The value is an independently auditable decision surface for the next prospective native convergence experiment.

## 再現方法（ローカルPython、CLASSとネット接続不要）

```bash
cd RIMS_C40_EXACT_LOCAL_VETO_ENVELOPE_20261027
python c40_exact_local_veto_envelope.py --c39-artifact evidence/rims-c39-veto-source-terms_ORIGINAL.zip --out outputs/NEW_C40_AUDIT.json
python -m pytest -q tests/test_c39_audit.py tests/test_c40_exact_envelope.py
sha256sum -c SHA256SUMS.txt
```

`--out`は既存パスへの上書きを拒否します。付属 `outputs/C40_ACTUAL_FIXED_SLICE_AUDIT.json` をそのまま参照する場合、再出力は不要です。

## 保存と次段階

- C39検証済みフルZIPと実測Artifactを `evidence/` にそのまま保持。C37 original error, receipt, frozen inputを `reference/` に保持。
- C39既存監査Pythonおよび結果JSONを保持。C40追加は解析的判定と検証testsのみ。
- `protocol/C41_CONVERGENCE_PREDECLARATION_JA.md`: 実際のCLASS tolerance名をピン留め済みcommitで確認し、試験ごとに事前登録してからごく限定された診断計算を行う手順。**C41計算は未実行。**
- PRD/JCAP投稿級の物理証明・予言・測定優位性はまだ未達。RIMS専用。PORG、IFC、PBH/Hawkingとは混在しない。
