# C41 Numerical convergence and trajectory gate — advance protocol, NOT executed

**Date:** 2026-10-27 JST. **Author:** Shuji Maruyama. © 2026 Shuji Maruyama. All rights reserved.

## 0. Immutable baselines

- Frozen 81: `0893eb71e09208c2579652d405f54277647f92ce1de33ee8a0e492ce2547cda0`.
- Frozen `rims_002`: `9bc753d2dd2843160e43ca9c37e4480d78513ef372ee9618831cc4447da6a284`.
- C39 original ZIP: `08318f04e7d1e7a0edfa7a69eefd1c2dcf0c19c152ef4640db7b6b33df83e160`.
- Native original source condition: `rims_enforce_stability && rims_stability_margin < -1e-10` (unmodified, never disabled/relaxed).
- Historical `c35_failure_prefix_matches` remains false for source-instrumented C39 as a literal check, with a separately proven line-rebased C37 full-text identity.
- No change to `rims_phi_ref`, `Omega`, `alpha_U`, `phi_t`, initial conditions, `scf_parameters`, shooting seeds or physics; no rescue by retuning.

## 1. Preflight: prove precision controls in *pinned* CLASS

Identify accepted precision names in the exact pinned upstream CLASS commit `e85808324f51fc694d12e3ed7439552a3c3f9540` and the two original RIMS patch SHA256 locks. Candidate documented knobs in the CLASS family are `tol_background_integration` (ODE tolerance) and `back_integration_stepsize` (background table sampling). **Do not presume their meanings/defaults from a different CLASS release**. Inspect the actual `source/input.c`, `source/background.c`, `include/precisions.h`, defaults file and native parser before choosing values. `tol_shooting_*` affects the normalization/shooting algorithm: hold it fixed, and distinguish different shooting iterates from a genuine integration convergence test. If a candidate precision input is unsupported, stop with a recorded failure, do not silently omit it.

## 2. Register experiment BEFORE native execution

Predeclare a minimal bounded grid: baseline pinned-default settings (C39 evidence, not an extra unique case) and at most **two further numerical solver tolerance settings** for the identical `rims_002` case, after resolving their actual defaults/ranges from the pinned source. Record precise numbers, rationale, expected accuracy and runtime cap in an immutable machine-readable registry before the first new compute. Changes to sampling and error control must be separated rather than mixed. Save compiled CLASS extension SHA256, full command-line/input parameter dictionary, source SHA256, process stdout/stderr, native error and traceback, all veto events, walltime and exit code, including all failures.

## 3. What to compare and what NOT to compare

The current original veto overshoot `4.938972201e-13` is *small*. Merely observing a positive overshoot at two tolerances is not a convergence proof: the first sampled triggering state shifts when integrator/sampling steps change. Prefer a **bracketed root in a common variable (`a` or `ln a`)** using source-only pre-veto sampled margins and final first veto state, preserving the original rejection. Compare both the bracket position and the pre-rejection source terms at appropriately matched or interpolated times, keeping interpolation uncertainties. A fixed-`a` re-evaluation beyond a previously vetoed trajectory must not be performed by silently disabling the gate.

Default acceptable reporting states:
- `ROOT_BRACKET_CONVERGED` only after explicitly predeclared **non-trivial** tightening and measurable bracket overlap/refinement with a documented uncertainty estimate.
- `SAME_NEGATIVE_SOURCE_SIGN_NOT_CONVERGED` if multiple runs reproduce the negative sign but lack root bracket/error bound.
- `NUMERICAL_UNRESOLVED` if solver trajectories, root locations, or signs disagree; do not pick a favorable result.
- `SHOOTING_FAILED_WITH_VETO` if only the existing failure recurs, even after arithmetic verification.
- `SOURCE_RECORD_UNAVAILABLE` if instrumentation fails; **fail closed**.

Numerical tolerance is not the physical stability threshold. All demonstrations require immutable safety guard, full provenance, and convergence output. A `source-terms-one` rerun on unchanged settings is *not* by itself a convergence experiment.

## 4. Separate physical propagation stability gate

`m_eff²/H²` at a shooting iterate is not the complete gauge-invariant propagating eigenfrequency. Require the full coupled scalar–dark-matter perturbation system with kinetic matrix, gradient matrix, ghost/hyperbolicity tests and growth integrated along a **valid normalized final background** before classifying any physical tachyon, ghost or gradient instability. Reject claims that the negative source ratio (~1e-10) by itself proves a catastrophic instability.

## 5. Observables / novelty firewall

Only after numerical viability can RIMS provide independently registered falsifiable predictions for matched cosmological observables (CMB, lensing, BAO/RSD, growth, consistency across gauges) against ΛCDM and competing interacting-dark-sector scenarios under the same priors/likelihood/code and data splits. Existing native seven-mode RIMS evolution frozen in V18_39 and C39 shooting-stage viability should remain two distinct provenance branches. No GetDist R-1<0.01 or ESS>=1000 from production is presently evidenced by this run. No Bayes factor, detection, improvement or model preference claim.

**Do not dispatch C41 numerical runs automatically. This protocol is static and prospective.**
