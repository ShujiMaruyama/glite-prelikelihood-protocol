"""Pure, local, fail-closed regression checks. No native CLASS run."""
import math
import json
import shutil
import sys
from pathlib import Path
import pytest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from c40_exact_local_veto_envelope import (
    analytic_curvature,analytic_curvature_completed_square,fixed_slice,
    evaluate, RAW_ARTIFACT_SHA256)
from audit_c39_run2 import AuditFailure,sha
ROOT=Path(__file__).resolve().parents[1]
ARTIFACT=ROOT/'evidence/rims-c39-veto-source-terms_ORIGINAL.zip'

@pytest.mark.parametrize('s',[0.,.01,1/3,.4,.55,.65,2/3,.9,1.])
def test_completed_square_identity_on_full_bounded_domain(s):
    assert math.isclose(analytic_curvature(s,.01),analytic_curvature_completed_square(s,.01),rel_tol=2e-14,abs_tol=1e-20)

def test_unique_minimum_curvature_at_two_thirds():
    a=.01
    x=analytic_curvature(2/3,a)
    assert math.isclose(x,-a*a/3,rel_tol=1e-14)
    for s in [0,.2,1/3,.5,.65,.8,1.]:
        assert analytic_curvature(s,a)>x

def test_curvature_sign_and_zeroes():
    assert analytic_curvature(0,.01)>0
    assert math.isclose(analytic_curvature(1/3,.01),0,abs_tol=1e-20)
    assert analytic_curvature(.65,.01)<0
    assert analytic_curvature(1,.01)==0

def test_no_veto_when_alpha_zero_and_A_nonnegative():
    x=fixed_slice(0,1e-6,0.,1e-10,.65)
    assert not x['source_veto_predicted']
    assert x['strict_veto_s_interval_at_fixed_A_U'] is None

def test_strict_boundary_excluded_at_s_window_endpoints():
    r=fixed_slice(.01,1.0074576162489683e-6,0.,1e-10,.65)
    lo,hi=r['strict_veto_s_interval_at_fixed_A_U']
    for k in (lo,hi):
        value=fixed_slice(.01,1.0074576162489683e-6,0.,1e-10,k)['predicted_meff2_over_H2']
        assert math.isclose(value,-1e-10,rel_tol=1e-13,abs_tol=1e-24)
    assert r['source_veto_predicted']
    assert lo<.65<hi

def test_veto_extinguished_if_U_leq_A_plus_tau():
    x=fixed_slice(.01,5e-7,0.,1e-10,2/3)
    assert x['strict_veto_s_interval_at_fixed_A_U'] is None
    assert not x['source_veto_predicted']

def test_negative_A_counterexample_validates_slice_only():
    x=fixed_slice(0,0,-2e-10,1e-10,.5)
    assert x['source_veto_predicted']
    assert x['strict_veto_s_interval_at_fixed_A_U'] is None  # no coupling-driven interval

def test_nonfinite_and_illegal_physical_domain_fails():
    for values in ((float('nan'),1,0,1e-10,.5),(.1,-1,0,1e-10,.5),(.1,1,0,-1e-10,.5),(.1,1,0,1e-10,1.01)):
        with pytest.raises(AuditFailure): fixed_slice(*values)

def test_observed_c39_artifact_and_computed_audit_consistent():
    r=evaluate(ARTIFACT)
    assert sha(ARTIFACT.read_bytes())==RAW_ARTIFACT_SHA256
    assert r['provenance']['literal_C35_prefix_match'] is False
    assert r['provenance']['source_line_rebased_C37_full_exception_match'] is True
    assert r['provenance']['new_native_tries_in_C40']==0
    assert r['boundaries']['normalized_final_background'] is False
    assert r['boundaries']['production_posterior'] is False
    assert r['fixed_slice_condition']['source_veto_predicted']
    assert r['analytic_identity']['fraction_of_most_negative_curvature']==pytest.approx(.9975,rel=1e-9)

def test_actual_local_slice_s_boundaries_and_margins():
    r=evaluate(ARTIFACT)
    v=r['fixed_slice_condition']
    assert v['strict_veto_s_interval_at_fixed_A_U']==pytest.approx([.6379875765259604,.6953457568073729],rel=1e-12)
    assert v['local_veto_excess']==pytest.approx(4.938972201072781e-13,rel=1e-12)
    assert v['predicted_meff2_over_H2']==pytest.approx(-1.0049389722010728e-10,rel=1e-11)

def test_no_altered_zip_is_promoted(tmp_path):
    p=tmp_path/'tampered-c39.zip';shutil.copyfile(ARTIFACT,p)
    with p.open('ab') as f:f.write(b'\nMUTATED')
    with pytest.raises(AuditFailure,match='SHA256 mismatch'):evaluate(p)

def test_read_only_evaluation_no_local_writes(tmp_path):
    before={str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in str(p) and '.pytest_cache' not in str(p)}
    evaluate(ARTIFACT)
    after={str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in str(p) and '.pytest_cache' not in str(p)}
    assert before==after

def test_existing_output_is_never_overwritten(tmp_path,monkeypatch):
    from c40_exact_local_veto_envelope import main
    p=tmp_path/'existing.json';p.write_text('KEEP')
    monkeypatch.setattr(sys,'argv',['c40','--c39-artifact',str(ARTIFACT),'--out',str(p)])
    with pytest.raises(AuditFailure,match='overwrite'):main()
    assert p.read_text()=='KEEP'

def test_no_premature_physical_claims_in_export():
    a=evaluate(ARTIFACT)
    assert a['boundaries']['numerical_convergence_proven'] is False
    assert a['boundaries']['physical_perturbation_eigenvalue_computed'] is False
    assert a['boundaries']['ghost_safety_proven'] is False
    assert a['boundaries']['tachyon_or_gradient_instability_proven'] is False
    assert a['boundaries']['observational_preference_or_detection'] is False
