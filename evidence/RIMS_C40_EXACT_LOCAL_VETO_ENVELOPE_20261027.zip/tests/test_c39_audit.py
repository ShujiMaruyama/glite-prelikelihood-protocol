import sys
from pathlib import Path
import pytest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from audit_c39_run2 import (old_reference,expected_native_error,verify_lineage_native_error,
    AuditFailure,sha,CASE_SHA,FREEZE_SHA,ORIGINAL_PREFIX_SHA,
    parse_term_line,MARKER,EXPECTED_FRAMES,C39_SOURCE_ADDED_LINES)

def receipt(error,matched):
    return {'error_sha256':sha(error),'full_error_bytes':len(error),
       'c35_original_truncated_error_prefix_sha256':ORIGINAL_PREFIX_SHA,
       'c35_failure_prefix_matches':matched}

def test_baseline_source_sha_and_lineage():
    b,r=old_reference();assert r['case_sha256']==CASE_SHA
    new=expected_native_error(b);d=verify_lineage_native_error(new,receipt(new,False))
    assert d['source_line_shift']==21 and d['byte_exact_excluding_line_renumbering']
    assert d['historic_C35_SHA_failure_preserved']

def test_four_frames_shift():
    b,_=old_reference();new=expected_native_error(b)
    for key,nums in EXPECTED_FRAMES.items():
        for n in nums:
            assert (key+'(L:'+str(n+C39_SOURCE_ADDED_LINES)+')').encode() in new
            assert (key+'(L:'+str(n)+')').encode() in b

def test_any_unexpected_text_mutation_fails():
    b,_=old_reference();new=expected_native_error(b)
    changed=new.replace(b'Shooting failed',b'Shooting PASSED')
    with pytest.raises(AuditFailure,match='differs beyond'):
        verify_lineage_native_error(changed,receipt(changed,False))

def test_any_other_stack_frame_shift_fails():
    b,_=old_reference();new=expected_native_error(b).replace(b'input_find_root(L:928)',b'input_find_root(L:929)')
    with pytest.raises(AuditFailure,match='differs beyond'):
        verify_lineage_native_error(new,receipt(new,False))

def test_c37_old_exception_cannot_masquerade_as_modified():
    b,_=old_reference()
    with pytest.raises(AuditFailure,match='differs beyond'):
        verify_lineage_native_error(b,receipt(b,True))

def test_false_historic_match_not_overwritten():
    b,_=old_reference();new=expected_native_error(b)
    with pytest.raises(AuditFailure,match='prefix test inconsistent'):
        verify_lineage_native_error(new,receipt(new,True))

def term_line(**change):
    d=dict(a=3.945905e-10,phi=4.1,s=.65,H=100.,Vpp=0.,rho_idm=1.,
         mass_curvature=-3.349796666666667e-7,
         matter_term=-1.004939e-6,raw_meff2=-1.004939e-6,
         h2=1e4,ratio=-1.004939e-10,tolerance=1e-10)
    d.update(change)
    return MARKER+' '+' '.join(k+'='+format(v,'.17g') for k,v in d.items())

def test_synthetic_source_mass_and_excess():
    r=parse_term_line(term_line());assert r['classification']=='potential_positive_coupling_negative'
    assert r['veto_excess']==pytest.approx(4.939e-13)

def test_source_mass_falsification_guard():
    with pytest.raises(AuditFailure,match='Matter term'):
        parse_term_line(term_line(matter_term=-0.2))

def test_tolerance_not_relaxed():
    with pytest.raises(AuditFailure,match='threshold changed'):
        parse_term_line(term_line(tolerance=1e-9))

def test_false_positive_veto_rejected():
    with pytest.raises(AuditFailure,match='No original'):
        parse_term_line(term_line(Vpp=2e-6,raw_meff2=9.95061e-7,ratio=9.95061e-11))

def _make_synthetic_zip(p,alter=False):
    """Entire mock archive is synthetic, not a real C39 execution."""
    import json,hashlib,zipfile
    from audit_c39_run2 import ORIGINAL_INPUT_SHA,sha,expected_native_error,old_reference
    old,ref=old_reference()
    # original_input preserved in C38 source package and is immutable evidence
    c37input=Path(__file__).resolve().parents[1]/'reference/C37_ORIGINAL_INPUT.json'
    inp=c37input.read_bytes()
    assert sha(inp)==ORIGINAL_INPUT_SHA
    err=expected_native_error(old)
    r={"case_id":"rims_002","case_sha256":CASE_SHA,"freeze_sha256":FREEZE_SHA,
       "compute_attempts":1,"status":"ORIGINAL_SHOOTING_FAILURE_REPRODUCED",
       "normalization_or_final_background_certified":False,
       "retuned_parameters":False,"MCMC":False,
       "input_sha256":sha(inp),**receipt(err,False)}
    src={'schema':'rims-c39-source-overlay-v1','source_sha256_before_overlay':'a'*64,
       'reconstruction_original_sha256':'a'*64,'source_sha256_after_overlay':'b'*64,
       'veto_gate_preserved':True,'changed_scientific_parameters':False,
       'changed_tolerance':False,'retuned_shooting':False,
       'only_addition':'stderr diagnostic on original native veto branch'}
    entries={
       'probe/receipt.json':json.dumps(r).encode(),
       'probe/original_input.json':inp,
       'probe/full_CLASS_exception.txt':err,
       'c39_original_source_sha256.json':json.dumps(src).encode(),
       'full_process_stderr.txt':(term_line()+'\n').encode(),
       'subprocess_returncode.txt':b'0\n',
    }
    manifest=''.join(sha(data)+'  ./'+name+'\n' for name,data in sorted(entries.items()))
    entries['SHA256SUMS.txt']=manifest.encode()
    if alter:
        entries['full_process_stderr.txt']+=b'UNDECLARED_MODIFICATION\n'
    with zipfile.ZipFile(p,'w',compression=zipfile.ZIP_DEFLATED) as z:
        for name,dat in entries.items():z.writestr(name,dat)

def test_full_readonly_mock_zip_honors_sha_and_original_veto(tmp_path):
    from audit_c39_run2 import audit_zip
    z=tmp_path/'fixture_SYNTHETIC.zip';_make_synthetic_zip(z)
    result=audit_zip(z)
    assert result['trigger_count']==1
    assert result['lineage']['byte_exact_excluding_line_renumbering']
    assert result['underlying_native_solution']=='SOLVER_FAILED'
    assert not result['solved_background']

def test_full_mock_zip_rejects_tampered_file(tmp_path):
    from audit_c39_run2 import audit_zip
    z=tmp_path/'fixture_SYNTHETIC_tampered.zip';_make_synthetic_zip(z,True)
    with pytest.raises(AuditFailure,match='SHA256 mismatch'):audit_zip(z)


def test_actual_run2_artifact_replays_full_audit():
    from audit_c39_run2 import audit_zip
    z=Path(__file__).resolve().parents[1]/'evidence/rims-c39-veto-source-terms_ORIGINAL.zip'
    result=audit_zip(z)
    assert result['trigger_count']==1
    assert result['lineage']['byte_exact_excluding_line_renumbering'] is True
    assert result['lineage']['historic_C35_SHA_failure_preserved'] is True
    r=result['veto_records_ALL'][0]
    assert r['classification']=='potential_positive_coupling_negative'
    assert r['cancellation_condition']==1.0
    assert r['potential_term_over_H2']>0
    assert r['idm_term_over_H2']<0
    assert result['underlying_native_solution']=='SOLVER_FAILED'
    assert result['solved_background'] is False

def test_analytic_mass_curvature_matches_native_original():
    from audit_c39_run2 import audit_zip
    import zipfile,json,math
    base=Path(__file__).resolve().parents[1]
    data=audit_zip(base/'evidence/rims-c39-veto-source-terms_ORIGINAL.zip')['veto_records_ALL'][0]
    with zipfile.ZipFile(base/'evidence/rims-c39-veto-source-terms_ORIGINAL.zip') as z:
        p=json.loads(z.read('probe/original_input.json'))
    a=p['rims_alpha_U'];s=data['s'];phi=data['phi']; phi_t=p['rims_phi_transition']
    pred= a*a*(1-s)*(1-3*s)
    assert math.isclose(pred,data['mass_curvature'],rel_tol=1e-13,abs_tol=1e-19)
    ex=2*a*(phi-phi_t)
    sb=1/(1+math.exp(-ex))
    assert math.isclose(sb,s,rel_tol=1e-13,abs_tol=1e-15)
    assert s>1/3
