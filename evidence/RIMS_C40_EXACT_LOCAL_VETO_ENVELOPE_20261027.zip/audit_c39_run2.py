#!/usr/bin/env python3
"""Read-only C39 artifact audit against original independently retained C37 error.

No CLASS execution, parameter change, likelihood, or tolerance relaxation.
The one allowed native error-text difference is exactly +21 physical background.c
source lines due to diagnostic-only overlay; all other bytes must agree.
"""
from __future__ import annotations
import argparse
import hashlib
import io
import json
import math
import re
from pathlib import Path
import zipfile

HERE=Path(__file__).resolve().parent
ORIGINAL_ERROR_SHA = '2809b68bd7b500fbda2f81d80dd5ed0e0acfd88a0f3b5de7e722a85117e008e0'
ORIGINAL_INPUT_SHA = 'b212691605dbb2e1c8a95bd26f5dfedd93b19d7b6a0b02a6b21df6b0055fb1a1'
ORIGINAL_PREFIX_SHA = 'eb8b7a6e5e52cec209141a7c359c5e6947b5479bb076df592558853b41b4beaf'
CASE_SHA = '9bc753d2dd2843160e43ca9c37e4480d78513ef372ee9618831cc4447da6a284'
FREEZE_SHA = '0893eb71e09208c2579652d405f54277647f92ce1de33ee8a0e492ce2547cda0'
C39_SOURCE_ADDED_LINES=21
EXPECTED_FRAMES={
    'background_init': (877,893),
    'background_solve': (2034,),
    'background_derivs': (2738,),
    'background_functions': (624,),
}
FIELDS=('a','phi','s','H','Vpp','rho_idm','mass_curvature',
        'matter_term','raw_meff2','h2','ratio','tolerance')
MARKER='RIMS_C39_TERMS_V1'
FRAME_RE=re.compile(rb'\b(background_init|background_solve|background_derivs|background_functions)\(L:(\d+)\)')

class AuditFailure(ValueError): pass

def sha(b:bytes)->str: return hashlib.sha256(b).hexdigest()
def require(ok:bool,reason:str):
    if not ok:raise AuditFailure(reason)

def old_reference()->tuple[bytes,dict]:
    b=(HERE/'reference/C37_ORIGINAL_NATIVE_ERROR.txt').read_bytes()
    r=json.loads((HERE/'reference/C37_ORIGINAL_RECEIPT.json').read_bytes())
    require(sha(b)==ORIGINAL_ERROR_SHA, 'C37 reference full error SHA changed')
    require(sha(b.decode('utf-8')[:1000].encode('utf-8'))==ORIGINAL_PREFIX_SHA, 'C37 first-1000 characters corrupted')
    require(r.get('error_sha256')==ORIGINAL_ERROR_SHA and r.get('case_sha256')==CASE_SHA and r.get('freeze_sha256')==FREEZE_SHA and r.get('c35_failure_prefix_matches') is True,'C37 receipt identity mismatch')
    return b,r

def expected_native_error(old:bytes, delta:int=C39_SOURCE_ADDED_LINES)->bytes:
    seen={}
    def replace(m):
        key=m.group(1).decode('ascii')
        old_n=int(m.group(2))
        require(old_n in EXPECTED_FRAMES[key], 'C37 reference frame unexpectedly changed: '+key)
        require((key,old_n) not in seen,'Duplicated C37 diagnostic frame: '+key)
        seen[(key,old_n)]=True
        return m.group(1)+b'(L:'+str(old_n+delta).encode('ascii')+b')'
    new=FRAME_RE.sub(replace,old)
    require(set(seen)=={(k,n) for k,nums in EXPECTED_FRAMES.items() for n in nums}, 'Original C37 stack frame set changed')
    return new

def verify_lineage_native_error(new:bytes,receipt:dict)->dict:
    original,_=old_reference()
    expected=expected_native_error(original)
    require(new==expected,'C39 exception differs beyond the five expected +21 background.c source-line shifts; do NOT override historic mismatch')
    require(receipt.get('error_sha256')==sha(new),'C39 error SHA receipt mismatch')
    require(receipt.get('full_error_bytes')==len(new),'C39 exception length receipt mismatch')
    require(receipt.get('c35_original_truncated_error_prefix_sha256')==ORIGINAL_PREFIX_SHA,'Historic digest mutated')
    # The full prefix is EXPECTED to differ after the diagnostic-only source insertion.
    computed=sha(new.decode('utf-8')[:1000].encode('utf-8'))
    require(receipt.get('c35_failure_prefix_matches') is (computed==ORIGINAL_PREFIX_SHA), 'C39 recorded old-prefix test inconsistent with real exception')
    return {'original_full_exception_sha256':ORIGINAL_ERROR_SHA,
            'new_native_full_exception_sha256':sha(new),
            'old_first1000_sha256':ORIGINAL_PREFIX_SHA,
            'new_first1000_sha256':computed,
            'byte_exact_excluding_line_renumbering':True,
            'source_line_shift':C39_SOURCE_ADDED_LINES,
            'shifted_native_frames':{k:[[v,v+C39_SOURCE_ADDED_LINES] for v in nums] for k,nums in EXPECTED_FRAMES.items()},
            'literal_old_sha_matches':computed==ORIGINAL_PREFIX_SHA,
            'historic_C35_SHA_failure_preserved':not receipt['c35_failure_prefix_matches']}

def find_member(z:zipfile.ZipFile,suffix:str)->str:
    names=[n for n in z.namelist() if n.rstrip('/').endswith(suffix) and not n.endswith('/')]
    require(len(names)==1,'ZIP path ambiguous or missing: '+suffix+': '+str(names))
    return names[0]

def verified_manifest(z:zipfile.ZipFile)->dict:
    path=find_member(z,'SHA256SUMS.txt')
    base=path.removesuffix('SHA256SUMS.txt')
    raw=z.read(path).decode('utf-8')
    count=0
    seen=set()
    for line in raw.splitlines():
        if not line.strip():continue
        m=re.fullmatch(r'([0-9a-f]{64})\s+\*?(\.\/)?([^\r\n]+)',line)
        require(m is not None,'Bad C39 internal SHA256 manifest line')
        digest,_,name=m.groups()
        canonical=base+name
        require(name not in seen,'Duplicate SHA256 manifest record')
        seen.add(name)
        require(canonical in z.namelist(),'Missing ZIP file named in manifest: '+name)
        require(sha(z.read(canonical))==digest,'C39 ZIP SHA256 mismatch: '+name)
        count+=1
    require(count>=4,'Too few C39 SHA-256 records')
    return {'file_count_verified':count,'internal_manifest_sha256':sha(z.read(path))}

def close(x,y,scale):return abs(x-y)<=5e-13*max(abs(scale),1e-300)
def parse_term_line(line:str)->dict:
    require(line.startswith(MARKER+' '),'Wrong native diagnostic marker')
    pairs=line[len(MARKER)+1:].split()
    require(len(pairs)==len(FIELDS),'Incomplete native source term record')
    d={}
    for fld, pair in zip(FIELDS,pairs):
        k,sep,v=pair.partition('=')
        require(sep=='=' and k==fld,'Wrong term field order: '+fld)
        try: val=float(v)
        except ValueError as exc:raise AuditFailure('Nonnumeric native value '+fld) from exc
        require(math.isfinite(val),'Nonfinite native source term '+fld)
        d[fld]=val
    require(0<d['a']<1 and 0<d['s']<1 and d['H']>0 and d['rho_idm']>=0 and d['h2']>0,'Invalid source state')
    require(d['tolerance']==1e-10,'Stability threshold changed')
    require(close(d['h2'],d['H']**2,d['h2']),'H² reconstruction failed')
    mt=3*d['rho_idm']*d['mass_curvature']
    require(close(d['matter_term'],mt,mt),'Matter term reconstruction failed')
    combined=d['Vpp']+d['matter_term']
    scale=max(abs(d['Vpp']),abs(d['matter_term']),abs(d['raw_meff2']))
    require(close(d['raw_meff2'],combined,scale),'Effective mass sum failed')
    rr=d['raw_meff2']/d['h2']
    require(close(d['ratio'],rr,max(abs(rr),abs(d['ratio']))),'Effective mass ratio failed')
    require(d['ratio'] < -d['tolerance'],'No original native stability rejection')
    a=d['Vpp']/d['h2'];b=d['matter_term']/d['h2']
    kval=(abs(d['Vpp'])+abs(d['matter_term']))/abs(d['raw_meff2'])
    d.update({'potential_term_over_H2':a,'idm_term_over_H2':b,
              'cancellation_condition':kval,
              'veto_excess':-d['ratio']-d['tolerance'],
              'classification': ('potential_positive_coupling_negative' if a>=0 and b<0 else
                 'potential_negative_coupling_positive' if a<0 and b>=0 else
                 'both_negative' if a<0 and b<0 else 'other_requires_review')})
    return d

def audit_zip(zippath:Path)->dict:
    require(zippath.is_file(),'C39 Run #2 Artifact ZIP missing')
    with zipfile.ZipFile(zippath) as z:
        require(z.testzip() is None,'ZIP CRC verification failed')
        manifest=verified_manifest(z)
        def read(path):return z.read(find_member(z,path))
        r=json.loads(read('probe/receipt.json'))
        src=json.loads(read('c39_original_source_sha256.json'))
        err=read('probe/full_CLASS_exception.txt')
        inp=read('probe/original_input.json')
        stderr=read('full_process_stderr.txt')
        require(r.get('case_id')=='rims_002' and r.get('case_sha256')==CASE_SHA and r.get('freeze_sha256')==FREEZE_SHA,'Frozen case identity changed')
        require(r.get('compute_attempts')==1 and r.get('status')=='ORIGINAL_SHOOTING_FAILURE_REPRODUCED' and r.get('normalization_or_final_background_certified') is False,'Native first failure not reproduced')
        require(r.get('retuned_parameters') is False and r.get('MCMC') is False,'Physics retuning or MCMC inappropriate')
        require(sha(inp)==ORIGINAL_INPUT_SHA and r.get('input_sha256')==ORIGINAL_INPUT_SHA,'Original exact input JSON changed')
        require(src.get('schema')=='rims-c39-source-overlay-v1' and src.get('source_sha256_before_overlay')==src.get('reconstruction_original_sha256'),'C39 source overlay not reversible')
        require(src.get('veto_gate_preserved') is True and src.get('changed_scientific_parameters') is False and src.get('changed_tolerance') is False and src.get('retuned_shooting') is False,'Original stability physics not preserved')
        require(src.get('only_addition')=='stderr diagnostic on original native veto branch','Unexpected overlay intent')
        before=src['source_sha256_before_overlay'];after=src['source_sha256_after_overlay']
        require(re.fullmatch('[0-9a-f]{64}',before) and re.fullmatch('[0-9a-f]{64}',after) and before!=after,'Invalid C39 source hashes')
        lineage=verify_lineage_native_error(err,r)
        logs=stderr.decode('utf-8').splitlines()
        terms=[parse_term_line(s) for s in logs if s.startswith(MARKER+' ')]
        require(len(terms)>0,'No native terms found in stderr; cannot classify source')
        # Keep every native triggering record, no selective trimming.
        rc=read('subprocess_returncode.txt').strip()
        require(rc==b'0','C39 native subprocess did not complete as c37-style diagnostic')
        return {'schema':'RIMS_C39_RUN2_READONLY_POSTMORTEM_AUDIT_V1',
                'source_artifact_sha256':sha(zippath.read_bytes()),
                'raw_native_stderr_sha256':sha(stderr),
                'run_c39_native_attempts':1,'unique_frozen_parameter_cases_added':0,
                'underlying_native_solution':'SOLVER_FAILED',
                'original_81_freeze':FREEZE_SHA,'case_id':'rims_002','input_sha256':ORIGINAL_INPUT_SHA,
                'original_source_hash':before,'diagnostic_overlay_hash':after,
                'lineage':lineage,'sha256_manifest':manifest,
                'veto_records_ALL':terms,'trigger_count':len(terms),
                'convergence_demonstrated':False,'production_posterior':False,
                'solved_background':False,'metric_preference':False}

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('zip',type=Path,help='Original GitHub Actions rims-c39-veto-source-terms Artifact ZIP')
    p.add_argument('--out',type=Path,required=True,help='New output path (never overwrites)')
    a=p.parse_args()
    require(not a.out.exists(),'Will not overwrite existing result')
    data=audit_zip(a.zip)
    a.out.write_text(json.dumps(data,indent=2,sort_keys=True,allow_nan=False)+'\n',encoding='utf-8')
    print('C39_READONLY_REPLAY_VERIFIED triggers=',data['trigger_count'])
    print('Original CLASS background outcome remains SOLVER_FAILED. NO posterior or viability claim.')
if __name__=='__main__':main()
