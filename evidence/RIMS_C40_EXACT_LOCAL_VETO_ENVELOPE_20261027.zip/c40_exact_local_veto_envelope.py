#!/usr/bin/env python3
"""RIMS C40: read-only exact *local* veto envelope at the original C39 failure.

All numeric observations are loaded from the original frozen GitHub Actions ZIP
via independent C39 forensic validation. No CLASS solve, MCMC, thresholds
changes, shooting changes, or physical stability inference is performed.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import math
from pathlib import Path
import zipfile
from audit_c39_run2 import audit_zip, sha, require, AuditFailure, ORIGINAL_INPUT_SHA

ROOT=Path(__file__).resolve().parent
RAW_ARTIFACT_SHA256='08318f04e7d1e7a0edfa7a69eefd1c2dcf0c19c152ef4640db7b6b33df83e160'
C39_AUDIT_SCHEMA='RIMS_C39_RUN2_READONLY_POSTMORTEM_AUDIT_V1'
C40_SCHEMA='RIMS_C40_FIXED_SLICE_EXACT_VETO_ENVELOPE_V1'
EPS_REL=2e-12


def analytic_curvature(s:float,alpha:float)->float:
    """m_{,phi phi}/m; exact source polynomial in the RIMS frozen patch."""
    require(math.isfinite(s) and 0 <= s <= 1, 'Occupancy must be in [0,1]')
    require(math.isfinite(alpha), 'Nonfinite coupling')
    return alpha*alpha*(1-s)*(1-3*s)


def analytic_curvature_completed_square(s:float,alpha:float)->float:
    return -(alpha*alpha/3.)*(1-9*(s-2/3.)**2)


def fixed_slice(alpha:float, rho_over_h2:float, potential_over_h2:float,
                tolerance:float, s:float)->dict:
    """Veto interval in s conditional on FROZEN rho/H² and Vpp/H².

    M(s)=A-U*(1-9*(s-2/3)^2), where U=(rho/H²)*alpha².
    Original veto M < -tau (strict). This is not a time trajectory.
    """
    vals=(alpha,rho_over_h2,potential_over_h2,tolerance,s)
    require(all(map(math.isfinite,vals)), 'Nonfinite fixed-slice input')
    require(rho_over_h2>=0 and tolerance>0 and 0<=s<=1, 'Invalid fixed-slice domain')
    U=rho_over_h2*alpha*alpha
    A=potential_over_h2
    f=1-9*(s-2/3)**2
    predicted=A-U*f
    q=None;lower=None;upper=None
    if U>0:
        q=(A+tolerance)/U
        if q<1:
            radius=math.sqrt((1-q)/9.)
            lower=max(0.,2/3.-radius)
            upper=min(1.,2/3.+radius)
            if not lower<upper:lower=upper=None
    return {
        'U_rho_alpha2_over_H2':U,
        'A_Vpp_over_H2':A,
        'shape_fraction_f':f,
        'predicted_meff2_over_H2':predicted,
        'source_veto_predicted':bool(predicted < -tolerance),
        'q_threshold_over_U':q,
        'strict_veto_s_interval_at_fixed_A_U': [lower,upper] if lower is not None else None,
        'global_s_extremum':2/3,
        'local_veto_excess':-(predicted+tolerance),
        'interpretation':'Only while A=Vpp/H² and U=(rho/H²)alpha² are held fixed; NOT a physical trajectory or cosmological viability domain',
    }


def close_rel(a:float,b:float,ref:float)->bool:
    return abs(a-b)<=EPS_REL*max(abs(ref),1e-300)


def evaluate(raw_archive:Path)->dict:
    require(raw_archive.is_file(), 'Missing C39 GitHub artifact')
    require(sha(raw_archive.read_bytes())==RAW_ARTIFACT_SHA256,'Original C39 artifact SHA256 mismatch')
    audit=audit_zip(raw_archive)
    require(audit['schema']==C39_AUDIT_SCHEMA and audit['trigger_count']==1,
            'C39 actual trigger count/schema changed')
    require(audit['lineage']['literal_old_sha_matches'] is False
            and audit['lineage']['historic_C35_SHA_failure_preserved'] is True
            and audit['underlying_native_solution']=='SOLVER_FAILED'
            and audit['solved_background'] is False,
            'Historical failure lineage has been improperly promoted')
    with zipfile.ZipFile(raw_archive) as z:
        raw_input=z.read('probe/original_input.json')
    require(sha(raw_input)==ORIGINAL_INPUT_SHA, 'Frozen physical input bytes changed')
    p=json.loads(raw_input)
    require(p.get('rims_enforce_stability')=='yes'
            and p.get('rims_require_normalization')=='no'
            and p.get('rims_stability_tolerance')==1e-10
            and p.get('rims_enabled')=='yes', 'Frozen stability gate or input flags changed')
    alpha=float(p['rims_alpha_U'])
    require(alpha==0.01, 'Frozen RIMS alpha changed')
    rec=audit['veto_records_ALL'][0]
    s=rec['s'];a=rec['a'];rho_over_h2=rec['rho_idm']/rec['h2']
    curv=analytic_curvature(s,alpha)
    square=analytic_curvature_completed_square(s,alpha)
    require(close_rel(curv,rec['mass_curvature'],rec['mass_curvature']),
            'Native mass curvature differs from analytic patch formula')
    require(close_rel(square,curv,curv), 'Completed-square polynomial identity mismatch')
    ex=2*alpha*(rec['phi']-float(p['rims_phi_transition']))
    sigmoid=1/(1+math.exp(-ex)) if ex>=0 else math.exp(ex)/(1+math.exp(ex))
    require(close_rel(sigmoid,s,s),'Logistic occupancy of the original scalar state disagrees')
    result=fixed_slice(alpha,rho_over_h2,rec['Vpp']/rec['h2'],rec['tolerance'],s)
    require(close_rel(result['predicted_meff2_over_H2'],rec['ratio'],rec['ratio']),
            'Exact envelope mismatches the native CLASS effective mass ratio')
    require(close_rel(-rho_over_h2*alpha*alpha*result['shape_fraction_f'],
                      rec['idm_term_over_H2'],rec['idm_term_over_H2']),
            'Original dark-sector source contribution inconsistent with exact envelope')
    require(result['source_veto_predicted'],'Analytic local veto not reproduced')
    lo,hi=result['strict_veto_s_interval_at_fixed_A_U']
    require(lo<s<hi,'Observed rejection occupancy is outside conditional veto window')
    # C40 reports a numerical *slice*, not a claim of convergence or of viability.
    return {
      'schema':C40_SCHEMA,
      'date_jst':'2026-10-27',
      'provenance':{
        'original_artifact_SHA256':RAW_ARTIFACT_SHA256,
        'C39_native_exception_SHA256':audit['lineage']['new_native_full_exception_sha256'],
        'original_C37_exception_SHA256':audit['lineage']['original_full_exception_sha256'],
        'C39_original_81_case_design_SHA256':audit['original_81_freeze'],
        'original_input_sha256':audit['input_sha256'],
        'actual_case_id':'rims_002',
        'C39_native_tries_already_in_record':1,
        'new_native_tries_in_C40':0,
        'literal_C35_prefix_match':False,
        'source_line_rebased_C37_full_exception_match':True,
        'original_C39_source_guard_changed':False,
      },
      'observed_native_veto':{
        'a':a,'s':s,'H':rec['H'],'rho_idm':rec['rho_idm'],
        'Vpp':rec['Vpp'], 'mass_curvature':rec['mass_curvature'],
        'Vpp_over_H2':rec['potential_term_over_H2'],
        'dark_term_over_H2':rec['idm_term_over_H2'],
        'meff2_over_H2':rec['ratio'],
        'tolerance':rec['tolerance'],
        'native_overshoot_absolute':rec['veto_excess'],
        'native_cancellation_condition':rec['cancellation_condition'],
      },
      'analytic_identity':{
        'mass_curvature': 'alpha_U^2 (1-s)(1-3s) = -(alpha_U^2/3)[1-9(s-2/3)^2]',
        'exact_extremum_at_s':2/3,
        'most_negative_mass_curvature':-(alpha*alpha)/3,
        'fraction_of_most_negative_curvature':result['shape_fraction_f'],
        'shape_window_only_conditional': True,
      },
      'fixed_slice_condition':result,
      'boundaries':{
        'source_term_at_one_native_shooting_rejection_point':True,
        'normalized_final_background':False,
        'numerical_convergence_proven':False,
        'physical_perturbation_eigenvalue_computed':False,
        'tachyon_or_gradient_instability_proven':False,
        'ghost_safety_proven':False,
        'observational_preference_or_detection':False,
        'production_posterior':False,
        'no_81_case_batch':True,
      }
    }


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--c39-artifact',type=Path,required=True)
    parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args()
    require(not args.out.exists(),'Refusing to overwrite an earlier C40 audit')
    result=evaluate(args.c39_artifact)
    args.out.parent.mkdir(parents=True,exist_ok=True)
    args.out.write_text(json.dumps(result,sort_keys=True,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    print('C40_FIXED_SLICE_CONDITIONAL_ANALYTIC_ENVELOPE_PASS; CLASS_SOLVER_FAILED; NEW_NATIVE_TRIES=0')
    print('s interval at fixed inputs:',result['fixed_slice_condition']['strict_veto_s_interval_at_fixed_A_U'])

if __name__=='__main__':main()
